
export async function getResponse(query:string,params:string[]|[]){
	//Get data based on the query string and Parameters
		return ['response here']

}
